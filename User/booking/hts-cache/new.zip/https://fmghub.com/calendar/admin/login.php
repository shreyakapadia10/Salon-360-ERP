
<!DOCTYPE html>

<html>

    <head>

        <title>eCalendar - Login</title>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="apple-touch-icon" sizes="76x76" href="/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
        <meta name="theme-color" content="#ffffff">

        <!-- Bootstrap style -->

            <link href="../css/bootstrap.min.css" rel="stylesheet" media="screen">

        <!-- Main style -->

            <link rel="StyleSheet" href="login/css/style.css" type="text/css" />

        <style type="text/css">
            body { margin-top: 50px; }
        </style>

    </head>

    <body>

        <div style="background: #333; width: 100%; height: 50px; position: fixed; z-index: 999; margin-top: -50px;">
            <h2 style="float: left; color: #FFF; margin: 0; font-size: 22px; font-weight: 200; line-height: 50px; margin-left: 35px;">eCalendar</h2>
            <a href="https://codecanyon.net/item/ecalendar-responsive-events-calendar/9722895?ref=Lettro" style="width: 150px; height: 50px; display: block; color: #FFF; background: #8BC34A; line-height: 50px; text-align: center; font-weight: 100; float: right;
            ">Buy now</a>
        </div>

        <div class="container">

            <div class="box">

                <header>Control Panel</header>

                <section>

                    <form action="" method="post">

                        <input type="text" name="user" placeholder="Username" value="admin" /><br />

                        <input type="password" name="psw" placeholder="Password" value="admin" /><br />

                        <input type="submit" value="Enter" />

                    </form>


                </section>

            </div>

        </div>

    </body>

</html>